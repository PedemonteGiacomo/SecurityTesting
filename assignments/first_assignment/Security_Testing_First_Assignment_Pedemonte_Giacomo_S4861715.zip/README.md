# SecurityTesting
In this assignment the main goal is to obtain succesfull injections to understand how works Security testing in order to obtain a full vision of possible attacks caused by a bad manage of the code.

So, in this directory are contained several pages that are our target to obtain specific injections reported in the sample_cmdi_test.py.

The test are obtained using the requests module to make command injections, argument injections and blind injections.

The output of the execution of that file report with a green check if the tests passes in the sense that we handle and manage that particular injection, otherwise a red check in the other case.

Tests are performed on each different pages contained in this directory in order to obtain a full vision of the attacked performed.


